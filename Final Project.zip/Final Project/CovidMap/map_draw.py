from pyecharts import options as opts
from pyecharts.charts import Map
# pyecharts is a package that runs Echarts on python. Echarts is a data visualization JS tool open sourced by Baidu.
# The types of data visualization are very rich, but they have to be run on Java Web projects by importing the js library
import os # call system method


class Draw_map():

    def __init__(self):
        if not os.path.exists('./map/china'):
            os.makedirs('./map/china')

    def get_colour(self, a, b, c):
        result = '#' + ''.join(map((lambda x: "%02x" % x), (a, b, c)))
        return result.upper()


def to_map_city(self, area, variate, province, update_time):
    pieces = [
        {"max": 99999999, "min": 10000, "label": "≥10000", "color": self.get_colour(102, 2, 8)},
        {"max": 9999, "min": 1000, "label": "1000-9999", "color": self.get_colour(140, 13, 13)},
        {"max": 999, "min": 500, "label": "500-999", "color": self.get_colour(204, 41, 41)},
        {"max": 499, "min": 100, "label": "100-499", "color": self.get_colour(255, 123, 105)},
        {"max": 99, "min": 50, "label": "50-99", "color": self.get_colour(255, 170, 133)},
        {"max": 49, "min": 10, "label": "10-49", "color": self.get_colour(255, 202, 179)},
        {"max": 9, "min": 1, "label": "1-9", "color": self.get_colour(255, 228, 217)},
        {"max": 0, "min": 0, "label": "0", "color": self.get_colour(255, 255, 255)},
    ]

    c = (
        # set map size
        Map(init_opts=opts.InitOpts(width='1000px', height='880px'))
            # The zip function is used for list merging, packing the corresponding elements in the object into tuples (tuples), and creating a list of tuple pairs.
            .add("The cumulative number of confirmed cases", [list(z) for z in zip(area, variate)],
                 province, is_map_symbol_show=False)
            # Set the global variable is_piecewise to set whether the data is continuous,
            # is_show sets whether to display the legend
            .set_global_opts(
            title_opts=opts.TitleOpts(title="%s regional epidemic map distribution" % (province),
                                      subtitle='As of %s %s province epidemic distribution' % (update_time, province),
                                      pos_left="center", pos_top="10px"),
            legend_opts=opts.LegendOpts(is_show=False),
            visualmap_opts=opts.VisualMapOpts(max_=200, is_piecewise=True, pieces=pieces, ),
        )
            .render("./map/china/{}epidemic map.html".format(province))
    )


def to_map_china(self, area, variate, update_time):
    pieces = [{"max": 999999, "min": 1001, "label": ">10000", "color": "#8A0808"},
              {"max": 9999, "min": 1000, "label": "1000-9999", "color": "#B40404"},
              {"max": 999, "min": 100, "label": "100-999", "color": "#DF0101"},
              {"max": 99, "min": 10, "label": "10-99", "color": "#F78181"},
              {"max": 9, "min": 1, "label": "1-9", "color": "#F5A9A9"},
              {"max": 0, "min": 0, "label": "0", "color": "#FFFFFF"},
              ]

    c = (
        # set map size
        Map(init_opts=opts.InitOpts(width='1000px', height='880px'))
            .add("The cumulative number of confirmed cases", [list(z) for z in zip(area, variate)], "china",
                 is_map_symbol_show=False)
            .set_global_opts(title_opts=opts.TitleOpts(title="China Epidemic Map Distribution",
                                                       subtitle='As of %s China Epidemic Distribution' % (update_time),
                                                       pos_left="center", pos_top="10px"),
                             legend_opts=opts.LegendOpts(is_show=False),
                             visualmap_opts=opts.VisualMapOpts(max_=200, is_piecewise=True, pieces=pieces, ),
                             )
            .render("./map/China Epidemic Map.html")
    )