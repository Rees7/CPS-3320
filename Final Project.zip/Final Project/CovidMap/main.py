from get_data import Get_data

#get data

data = Get_data()
data.get_data()
time_in,time_out = data.get_time()
data.parse_data()


#draw maps
import execution
execution.china_map(time_in)
execution.province_map(time_in)