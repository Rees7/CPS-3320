import map_draw
import json

map = map_draw.Draw_map()
#Format
# retrieve data
with open('data.json', 'r') as file:
    data = file.read()
    #String to dictionary type
    data = json.loads(data)

#Refinement data, corresponding to each city name and corresponding information
#China Epidemic Map
def china_map(update_time):
    area = []
    confirmed = []

    # Traverse the list to get the information of each province
    for each in data:
        print(each)
        # get value by key
        area.append(each['area'])
        confirmed.append(each['confirmed'])
    map.to_map_china(area, confirmed, update_time)


# Epidemic map of provinces and municipalities directly under the Central Government
def province_map(update_time):
    for each in data:
        city = []
        confirmeds = []
        province = each['area']

        for each_city in each['subList']:
            city.append(each_city['city']+"city")
            confirmeds.append(each_city['confirmed'])
            map.to_map_city(city,confirmeds,province,update_time)
        if province == 'Shanghai' or 'Beijing' or 'Tianjin' or 'Chongqing':
            for each_city in each['subList']:
                city.append(each_city['city'])
                confirmeds.append(each_city['confirmed'])
                map.to_map_city(city,confirmeds,province,update_time)