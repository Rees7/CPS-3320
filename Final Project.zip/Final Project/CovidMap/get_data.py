import requests# is used to crawl data from the target website
from lxml import etree# for parsing data
import json#Information extraction

import re#regular expressionRegular expression
import openpyxl #excel, support reading and editing with openpyxl

class Get_data():

    def get_data(self):
        # target url
        url = "https://voice.baidu.com/act/newpneumonia/newpneumonia/"
        # fake request header
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)'
                          'Chrome/80.0.3987.149 Safari/537.36'
        }
        # Make a get request
        response = requests.get(url,headers=headers)
        # Write the result of the request to a file for analysis
        with open('html.txt', 'w') as file:
           file.write(response.text)

    # get update time
    def get_time(self):
        #text is the second parameter required for the following regular crawling
        with open('html.txt','r') as file:
            text = file.read()
        #Find the required data in the html file grabbed above, and find that there is one and only one "mapLastUpdatedTime", you can use regular expressions to grab it, and only need the result to return the first item in the list
        time_in = re.findall('"mapLastUpdatedTime":"(.*?)"',text)[0]
        time_out = re.findall('"foreignLastUpdatedTime":"(.*?)"',text)[0]
        print('Domestic epidemic update time is '+time_in)
        print('Foreign epidemic update time is '+time_out)
        return time_in,time_out
    #Analytical data
    def parse_data(self):
        with open('html.txt','r') as file:
            text = file.read()
        # Generate HTML object
        html = etree.HTML(text)
        # Analytical data
        #Get the text under the target tag
        result = html.xpath('//script[@type="application/json"]/text()')

        # Used to view the results when writing, the same below
        # print(type(result))

        #Since there is only one item in the returned result, it is converted from a string to a dictionary, which is convenient for subsequent information extraction
        result = result[0]
        # print(type(result))

        # convert string to dictionary type
        result = json.loads(result)
        #Add the type method to confirm the type
        # print(type(result))

        #The return result is a list, the list has only one item, and then find the next level tag
        #dumps convert python character type to string
        result = json.dumps(result['component'][0]['caseList'])
        # print(result)
        # print(type(result))

        with open('data.json','w') as file:
            file.write(result)
            print('Data has been written to json file...')

        #The above is the first step of data extraction

        response = requests.get("https://voice.baidu.com/act/newpneumonia/newpneumonia/")
        # Write the result of the request to a file for easy analysis
        with open('html.txt', 'w') as file:
            file.write(response.text)

        # Get Time
        time_in = re.findall('"mapLastUpdatedTime":"(.*?)"', response.text)[0]
        time_out = re.findall('"foreignLastUpdatedTime":"(.*?)"', response.text)[0]
        print(time_in)
        print(time_out)

        # Generate HTML object
        html = etree.HTML(response.text)
        # Analytical data
        result = html.xpath('//script[@type="application/json"]/text()')
        print(type(result))
        result = result[0]
        print(type(result))
        result = json.loads(result)
        print(type(result))
        # Take the data of each province as a dictionary
        data_in = result['component'][0]['caseList']
        for each in data_in:
            print(each)
            print("\n" + '*' * 20)

        data_out = result['component'][0]['globalList']
        for each in data_out:
            print(each)
            print("\n" + '*' * 20)

        '''
        confirmedRelative --> cumulative increment
        curedRelative --> cured increment
        curConfirm --> Existing diagnosis
        curConfirmRelative --> existing confirmed increment
        diedRelative --> Increment of death
        '''

        # Regularity----traverse each item in the list, you can find that each item (type: dictionary) represents a
        # province and other regions, the first 11 items of this dictionary are the epidemic data of the province,
        # When key = 'subList', the result is a list with only one item, the first item of the list is extracted,
        # and a series of dictionaries are obtained. The dictionary contains the epidemic data of the city.

        # Write the obtained data to the excel file
        # create a workbook
        wb = openpyxl.Workbook()
        # Create worksheets, each worksheet represents an area
        ws_in = wb.active
        ws_in.title = "Domestic Epidemic"
        ws_in.append(['province', 'cumulative diagnosis', 'death', 'cured', 'existing diagnosis',
                      'cumulative confirmed increment', 'death increment', 'cured increment', 'existing Diagnosis increment'])
        for each in data_in:
            temp_list = [each['area'], each['confirmed'], each['died'], each['crued'], each['curConfirm'],
                         each['confirmedRelative'], each['diedRelative'], each['curedRelative'],
                         each['curConfirmRelative']]
            for i in range(len(temp_list)):#Replace empty data with 0

                if temp_list[i] == '':
                    temp_list[i] = '0'
            ws_in.append(temp_list)

        # Get foreign epidemic data
        for each in data_out:
            print(each)
            print("\n" + '*' * 20)
            sheet_title = each['area']
            # Create a new worksheet
            ws_out = wb.create_sheet(sheet_title)
            ws_out.append(['Country', 'Cumulative Diagnosis', 'Death', 'Cure', 'Existing Diagnosis', 'Cumulative Diagnosis Increment'])
            for country in each['subList']:
                list_temp = [country['country'], country['confirmed'], country['died'], country['crued'],
                             country['curConfirm'], country['confirmedRelative']]
                for i in range(len(list_temp)):
                    if list_temp[i] == '':
                        list_temp[i] = '0'
                ws_out.append(list_temp)

            # save the excel file
            wb.save('./data.xlsx')