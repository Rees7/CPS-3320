import pandas as pd
import plotly.express as px
import matplotlib.pyplot as plt
from fbprophet import Prophet
import numpy as np
from sklearn.metrics import r2_score

plt.style.use("ggplot")

#read data, and data is provided by JHU on : https://ourworldindata.org/coronavirus-source-data
case = pd.read_csv("New_Case.csv")
death = pd.read_csv("New_Death.csv")


#Daily New Cases, store data in dataframe
count = []
for i in range(1,len(case)):
    count.append(sum(pd.to_numeric(case.iloc[i,1:].values)))

df = pd.DataFrame()
df["Date"] = case["Date"][1:]
df["Cases"] = count
df=df.set_index("Date")


#Daily New Deaths, store data in dataframe
count = []
for i in range(1,len(death)):
    count.append(sum(pd.to_numeric(death.iloc[i,1:].values)))
df["Deaths"] = count


#Forecase Under Facebook Prophet Model
#This part is from multiple blog :https://blog.csdn.net/weixin_26746401/article/details/108499016 && https://blog.csdn.net/weixin_26713521/article/details/108134429
class Fbprophet(object):
    def fit(self, data):    #set the data
        self.data = data
        self.model = Prophet(weekly_seasonality=True, daily_seasonality=False, yearly_seasonality=False)    #there is no need to use the season forecast as the virus does not look at the calendar, only enable the weekly one is enough
        self.model.fit(self.data)

    def forecast(self, periods, freq):  #enable the forecast function
        self.future = self.model.make_future_dataframe(periods=periods, freq=freq)
        self.forecast = self.model.predict(self.future)

    def plot(self, x_name="Years", y_name="Values"):    #draw the plot of the result of forecast
        self.model.plot(self.forecast, xlabel=x_name, ylabel=y_name, figsize=(10, 5))
        self.model.plot_components(self.forecast, figsize=(10, 5))

    def R2(self):   #calculate R2 to get the range of diviation
        return r2_score(self.data.y, self.forecast.yhat[:len(df)])

#get the f(x) need to fit
function_line = pd.DataFrame({"ds": [], "y": []})
function_line["ds"] = pd.to_datetime(df.index)
function_line["y"] = df.iloc[:, 0].values

#set the model, pridict from 6.1 (19 days after)
model = Fbprophet()
model.fit(function_line)
model.forecast(19, "D")
model.R2()

#set the days need to forecast (10 days set)
forecast = model.forecast[["ds", "yhat_lower", "yhat_upper", "yhat"]].tail(10).reset_index().set_index("ds").drop(
    "index", axis=1)

#show the area of diviation by using grey background
forecast["yhat"].plot(marker=".", figsize=(10, 5),color="LimeGreen")
plt.fill_between(x=forecast.index, y1=forecast["yhat_lower"], y2=forecast["yhat_upper"], color="Gray")
plt.legend(["ForeCast Line", "Bound"], loc="upper left")
plt.title("Forecasting of Next 10 Days Cases")
plt.show()