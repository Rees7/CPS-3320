import pandas as pd
import plotly.express as px
import matplotlib.pyplot as plt

import numpy as np
from sklearn.metrics import r2_score

plt.style.use("ggplot")

#read data, and data is provided by JHU on : https://ourworldindata.org/coronavirus-source-data
case = pd.read_csv("New_Case.csv")
death = pd.read_csv("New_Death.csv")


#Daily New Cases, shown in line chart, blue line is death and red line is the trend with mean value for every 15 days
count = []
for i in range(1,len(case)):
    count.append(sum(pd.to_numeric(case.iloc[i,1:].values)))

df = pd.DataFrame()
df["Date"] = case["Date"][1:]
df["Cases"] = count
df=df.set_index("Date")

df.Cases.plot(title="Daily Covid-19 New Cases",marker=".",figsize=(10,5),label="Daily Cases",color="Blue")  #draw the line of death, set its title, size and color
df.Cases.rolling(window=15).mean().plot(figsize=(10,5),label="Trend Line",color="Red")  #draw the line of mean value of death, set its title, size and color
plt.ylabel("Cases")
plt.legend()
plt.show()