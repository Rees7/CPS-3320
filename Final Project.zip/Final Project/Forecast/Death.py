import pandas as pd
import plotly.express as px
import matplotlib.pyplot as plt
import numpy as np

plt.style.use("ggplot")

#read data, and data is provided by JHU on : https://ourworldindata.org/coronavirus-source-data
case = pd.read_csv("New_Case.csv")
death = pd.read_csv("New_Death.csv")


#Daily New Deaths, shown in line chart,  red line is death and aqua line is the trend with mean value for every 15 days
count = []
for i in range(1,len(death)):
    count.append(sum(pd.to_numeric(death.iloc[i,1:].values)))

df = pd.DataFrame()
df["Date"] = case["Date"][1:]
df["Deaths"] = count
df=df.set_index("Date")

df.Deaths.plot(title="Daily Covid-19 New Deaths",marker=".",figsize=(10,5),label="Daily Deaths",color="Red")    #draw the line of death, set its title, size and color
df.Deaths.rolling(window=15).mean().plot(figsize=(10,5),label="Trend Line",color="Aqua")    #draw the line of mean value of death, set its title, size and color
plt.ylabel("Deaths")
plt.legend()
plt.show()